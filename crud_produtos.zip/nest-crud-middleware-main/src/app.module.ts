import { Module } from '@nestjs/common';
import { LivrosModule } from './books/books.module';
import { MongooseModule } from '@nestjs/mongoose';
import { NestModule, MiddlewareConsumer } from '@nestjs/common';
import { LoggerMiddleware } from './common/middleware/logger.middleware';
import { ProdutosModule } from './products/products.module';
import { ProductsController } from './products/products.controller';

@Module({
  imports: [MongooseModule.forRoot('mongodb://localhost/nest'), LivrosModule, ProdutosModule],
  controllers: [],
  providers: [],
})
export class AplicativoModule implements NestModule{
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LoggerMiddleware)
      .forRoutes(ProductsController);
  }
  
}
