import { Injectable } from '@nestjs/common';
import { CriarLivroDto } from './dto/criar-book.dto';
import { InjectModel } from '@nestjs/mongoose';
import { AtualizarLivroDto } from './dto/atualizar-book.dto';
import { Books } from './schemas/book.schema';
import { Model } from 'mongoose';

@Injectable()
export class LivrosService {
  constructor(@InjectModel(Books.name) private BooksModel: Model<Books>) {}

  async criar(criarCatDto: CriarLivroDto): Promise<Books> {
    const criardCat = new this.BooksModel(criarCatDto);
    return criardCat.save();
  }

  async encontrarTodos(): Promise<Books[]> {
    return this.BooksModel.find().exec();
  }

  encontrarUm(id: number) {
    return `This action returns a #${id} book`;
  }

  async atualizar(id: string, atualizarBookDto: AtualizarLivroDto): Promise<Books> {
    return this.BooksModel.findByIdAndUpdate(id, atualizarBookDto, { new: true }).exec();
  }

  async remover(id: string): Promise<Books> {
    return this.BooksModel.findByIdAndDelete(id).exec();
  }
}
