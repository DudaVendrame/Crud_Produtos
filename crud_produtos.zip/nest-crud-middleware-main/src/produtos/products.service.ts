import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CriarProdutoDto } from './dto/criar-product.dto';
import { AtualizarProdutoDto } from './dto/atualizar-product.dto';
import { Product, ProductDocument } from './schemas/produtos.schemas';

@Injectable()
export class ProdutosService {
  constructor(@InjectModel(Product.name) private readonly productModel: Model<ProductDocument>) {}

  async criar(criarProductDto: CriarProdutoDto): Promise<Product> {
    const criardProduct = new this.productModel(criarProductDto);
    return criardProduct.save();
  }

  async encontrarTodos(): Promise<Product[]> {
    return this.productModel.find().exec();
  }

  async encontrarUm(id: string): Promise<Product> {
    const product = await this.productModel.findById(id).exec();
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
    return product;
  }

  async atualizar(id: string, atualizarProductDto: AtualizarProdutoDto): Promise<Product> {
    const existingProduct = await this.productModel.findByIdAndUpdate(id, atualizarProductDto, { new: true }).exec();
    if (!existingProduct) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
    return existingProduct;
  }

  async remover(id: string): Promise<Product> {
    const deletedProduct = await this.productModel.findByIdAndDelete(id).exec();
    if (!deletedProduct) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
    return deletedProduct;
  }
}