import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ProdutosService } from './products.service';
import { CriarProdutoDto } from './dto/create-product.dto';
import { AtualizarProdutoDto } from './dto/update-product.dto';
import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
} from '@nestjs/common';

@Controller('produtos')
export class ProdutosController {
  constructor(private readonly produtosService: ProdutosService) {}

  @Post()
  create(@Body() createProductDto: CriarProdutoDto) {
    return this.produtosService.create(createProductDto);
  }

  @Get()
  async findAll() {
    throw new HttpException('Forbidden', HttpStatus.NOT_FOUND);
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const product = await this.produtosService.findOne(id);
      return product;
    } catch (error) {
      throw new HttpException({
        status: HttpStatus.INTERNAL_SERVER_ERROR,
        error: 'Erro ao buscar o produto',
      }, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateProductDto: AtualizarProdutoDto) {
    return this.produtosService.update(id, updateProductDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.produtosService.remove(id);
  }
}
